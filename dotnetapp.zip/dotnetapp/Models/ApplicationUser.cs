using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
 using Microsoft.AspNetCore.Identity;
namespace dotnetapp.Models
{
  

public class ApplicationUser : IdentityUser
{
    // Additional properties can be added here
    public int UserID { get; set; }
    public string Password { get; set; }
}

}